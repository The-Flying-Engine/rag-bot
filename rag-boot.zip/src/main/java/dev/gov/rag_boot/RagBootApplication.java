package dev.gov.rag_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RagBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RagBootApplication.class, args);
	}

}
